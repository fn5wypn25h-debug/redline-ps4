#pragma once

#include <cstddef>
#include <string>
#include <vector>

namespace redline {
struct MenuItem {
    std::string title;
    std::string description;
};

class Menu {
public:
    Menu();
    void next();
    void previous();
    std::size_t selected_index() const noexcept;
    const std::vector<MenuItem>& items() const noexcept;

private:
    std::vector<MenuItem> items_;
    std::size_t selected_ = 0;
};
} // namespace redline
