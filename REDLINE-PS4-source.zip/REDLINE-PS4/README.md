# REDLINE PS4 — homebrew starter project

A small C++ starter project for an OpenOrbis PS4 homebrew application. This archive contains **source code only**; it is not a compiled or installable PKG.

## Important firmware note

The official GoldHEN releases page currently lists supported firmware through 11.00 (including 9.60 and 10.00/10.01). It does not list 14.02. A homebrew package does not itself jailbreak a console or enable Debug Settings. Verify a compatible, legitimate homebrew-enabling environment for the exact console firmware before attempting installation. Do not update or downgrade the console based on unofficial claims.

## Build environment

The easiest Chromebook route, if available to your GitHub account, is GitHub Codespaces using a Linux x86_64 container. This project still requires the official OpenOrbis toolchain and its package tools. Follow the toolchain's own release/install instructions:

- https://github.com/OpenOrbis/OpenOrbis-PS4-Toolchain
- https://github.com/OpenOrbis/OpenOrbis-PS4-Toolchain/releases

Set `OO_PS4_TOOLCHAIN` to the extracted toolchain root. Use the official sample Makefiles as the source of truth for compiler/linker flags and packaging rules; those details can change between toolchain releases.

## Project layout

- `src/main.cpp`: minimal app entry point and menu model
- `include/menu.hpp`: menu declarations
- `Makefile`: deliberately conservative placeholder; import the exact build rules from the official `hello_world` or graphics sample for your installed toolchain version
- `.github/workflows/`: manual workflow placeholder, not an automated PKG builder

## Next steps

1. Create a private or public GitHub repository and upload this folder.
2. Open it in Codespaces if your account offers it.
3. Install/download the official OpenOrbis release appropriate for Linux x86_64.
4. Start from the official `hello_world` sample and verify that sample builds before integrating REDLINE's source.
5. Only after a successful build, package using the official sample's GP4 / `create-gp4` / `pkg_build` flow.
6. Confirm firmware and homebrew-enabler compatibility before transferring any PKG to the console.

No payloads, exploits, game cheats, or anti-cheat bypasses are included.
