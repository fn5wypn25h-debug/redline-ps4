#include "menu.hpp"
#include <cstdio>

namespace redline {
Menu::Menu() : items_{
    {"SYSTEM INFO", "Console information (read-only)"},
    {"CONTROLLER", "Controller utility settings"},
    {"CONFIGURATION", "Save REDLINE preferences"},
    {"PERFORMANCE", "Basic application diagnostics"},
    {"ABOUT", "About REDLINE PS4"},
    {"EXIT", "Close REDLINE"}
} {}

void Menu::next() {
    if (!items_.empty()) selected_ = (selected_ + 1) % items_.size();
}
void Menu::previous() {
    if (!items_.empty()) selected_ = (selected_ + items_.size() - 1) % items_.size();
}
std::size_t Menu::selected_index() const noexcept { return selected_; }
const std::vector<MenuItem>& Menu::items() const noexcept { return items_; }
} // namespace redline

// Portable smoke-test entry point. Replace with the entry-point and graphics/input
// initialization pattern from the official OpenOrbis hello_world/graphics sample
// when integrating into the PS4 target. This file alone is not a PS4 eboot.
int main() {
    redline::Menu menu;
    std::puts("REDLINE PS4 — source prototype");
    for (std::size_t i = 0; i < menu.items().size(); ++i) {
        std::printf("%c %s — %s\n", i == menu.selected_index() ? '>' : ' ',
                    menu.items()[i].title.c_str(),
                    menu.items()[i].description.c_str());
    }
    return 0;
}
