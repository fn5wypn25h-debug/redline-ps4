This directory is intentionally not an automated PS4 PKG workflow yet.
First validate the official OpenOrbis toolchain and build its unmodified hello_world
sample in the chosen Linux x86_64 environment. Then adapt that exact sample Makefile
and packaging recipe here. Avoid pinning an unverified toolchain download URL or
claiming a PKG was produced when the build did not complete.
